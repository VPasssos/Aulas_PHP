
<?php
require_once 'conexao.php';
require_once 'funcoes.php';
require_login();
