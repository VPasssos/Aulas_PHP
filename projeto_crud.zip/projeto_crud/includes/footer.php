
</main>
<footer class="container">
  <hr>
  <p>Projeto CRUD PHP • Exemplos educacionais • <?php echo date('Y'); ?></p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
