
<?php
require_once 'includes/auth.php';
?>
<?php include 'includes/header.php'; ?>
<div class="p-4 bg-light rounded-3">
  <h1 class="display-6">Bem-vindo(a) à Área Administrativa</h1>
  <p class="lead">Use o menu superior para gerenciar usuários.</p>
  <hr>
  <p>Somente usuários autenticados podem ver esta página.</p>
</div>
<?php include 'includes/footer.php'; ?>
