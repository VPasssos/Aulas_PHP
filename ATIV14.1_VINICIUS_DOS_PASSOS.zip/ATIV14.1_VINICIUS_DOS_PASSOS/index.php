<?php include 'includes/cabecalho.php'; ?>
<h1 class="text-center">Bem-vindo ao CRUD de Funcionários</h1>
<p class="text-center">Use o menu acima para navegar.</p>
</div>
</body>
</html>