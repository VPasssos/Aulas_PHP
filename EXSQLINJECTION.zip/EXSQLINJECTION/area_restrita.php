<?php

    echo "<h1> 🚨 Área Restrita 🚨</h1>";

    echo "<p>Você nao deveria esta aqui, mas conseguiy acessar devida a uma falha de segurança</p>";
    
    echo "<p>Isso mostra como ataques SQL injection podem compromter sistemas sem proteção adequada</p>";

?>